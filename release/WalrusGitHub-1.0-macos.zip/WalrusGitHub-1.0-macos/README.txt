Walrus GitHub 1.0 — macOS (by MrSmartAss)
=========================================
Установка:  двойной клик по install.command
   (если macOS блокирует: правый клик -> Открыть -> Открыть)
Удаление:   двойной клик по uninstall.command
Требуется Python 3.10+ с python.org
Автор: https://github.com/mrsmartass700-blip
