#!/usr/bin/env bash
OK=$'\033[1;32m'; NC=$'\033[0m'
rm -rf "$HOME/Applications/Walrus GitHub.app" \
       "$HOME/Library/Application Support/WalrusGitHub"
echo "${OK}✔ Walrus GitHub удалён.${NC}"
echo "  Настройки и токен: rm -rf ~/.github_manager (вручную, если нужно)"
read -r -p "Нажмите Enter, чтобы закрыть…"
