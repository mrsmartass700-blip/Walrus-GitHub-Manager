#!/usr/bin/env bash
set -e
B=$'\033[1m'; DIM=$'\033[2m'; OK=$'\033[1;32m'; ERR=$'\033[1;31m'
ACC=$'\033[1;94m'; NC=$'\033[0m'
step() { echo "  ${ACC}◆${NC} $1"; }
done_() { echo "  ${OK}✔${NC} $1"; }
fail() { echo "  ${ERR}✘ $1${NC}"; read -r -p "Нажмите Enter…"; exit 1; }
clear 2>/dev/null || true
echo "
${ACC}   ╭──────────────────────────────────────────────╮
   │                                              │
   │      🦭  Walrus GitHub — установка           │
   │      by MrSmartAss                           │
   │                                              │
   ╰──────────────────────────────────────────────╯${NC}
"
HERE="$(cd "$(dirname "$0")" && pwd)"
SUPPORT="$HOME/Library/Application Support/WalrusGitHub"
APP="$HOME/Applications/Walrus GitHub.app"
step "Проверяю Python 3…"
command -v python3 >/dev/null 2>&1 || \
  fail "Python 3 не найден. Установите с https://python.org и запустите снова."
PYVER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
done_ "Python $PYVER найден"
python3 -c "import tkinter" 2>/dev/null || \
  fail "У вашего Python нет tkinter. Поставьте Python с python.org."
step "Создаю окружение и ставлю зависимости (1–2 минуты)…"
mkdir -p "$SUPPORT"
python3 -m venv "$SUPPORT/venv"
"$SUPPORT/venv/bin/pip" install --quiet --upgrade pip
"$SUPPORT/venv/bin/pip" install --quiet -r "$HERE/src/requirements.txt"
done_ "Зависимости установлены"
step "Копирую программу…"
mkdir -p "$SUPPORT/app"
cp -R "$HERE/src/." "$SUPPORT/app/"
done_ "Файлы на месте"
step "Собираю иконку…"
ICONSET="$SUPPORT/icon.iconset"
rm -rf "$ICONSET"; mkdir -p "$ICONSET"
for s in 16 32 64 128 256; do
  sips -z $s $s "$HERE/src/assets/icon_256.png" \
       --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
done
iconutil -c icns "$ICONSET" -o "$SUPPORT/icon.icns" 2>/dev/null || true
done_ "Иконка готова"
step "Создаю приложение Walrus GitHub.app…"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cat > "$APP/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
 "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Walrus GitHub</string>
  <key>CFBundleDisplayName</key><string>Walrus GitHub</string>
  <key>CFBundleIdentifier</key><string>dev.mrsmartass.walrusgithub</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>CFBundleExecutable</key><string>launcher</string>
  <key>CFBundleIconFile</key><string>icon</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
EOF
cat > "$APP/Contents/MacOS/launcher" <<EOF
#!/usr/bin/env bash
cd "\$HOME/Library/Application Support/WalrusGitHub/app"
exec "\$HOME/Library/Application Support/WalrusGitHub/venv/bin/python" app.py
EOF
chmod +x "$APP/Contents/MacOS/launcher"
[ -f "$SUPPORT/icon.icns" ] && cp "$SUPPORT/icon.icns" "$APP/Contents/Resources/icon.icns"
done_ "Приложение создано"
echo "
${OK}${B}  ✅ Готово! Walrus GitHub установлен.${NC}

  Запуск:  Finder → Программы (у пользователя) → ${B}Walrus GitHub${NC}
  Автор:   ${DIM}https://github.com/mrsmartass700-blip${NC}
  Удалить: ${DIM}двойной клик по uninstall.command${NC}
"
open "$HOME/Applications" 2>/dev/null || true
read -r -p "Нажмите Enter, чтобы закрыть…"
